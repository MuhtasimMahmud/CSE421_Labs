import socket

HEADER = 16
PORT = 5050
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
FORMAT = "utf-8"
DISCONNECT_MSG = "End"

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)

server.listen()
print("Server is listening!")
conn, addr = server.accept()
connected = True

while connected:
    msg_length = conn.recv(HEADER).decode(FORMAT)
    if msg_length:
        msg_length = int(msg_length)
        msg = conn.recv(msg_length).decode(FORMAT)
        if msg == DISCONNECT_MSG:
            connected = False
            conn.send("Goodbye".encode(FORMAT))
        else:
            salary=0
            if int(msg)<=40 :
                salary=200*int(msg)
                conn.send(f"Salary is Tk{salary}".encode(FORMAT))
            elif int(msg)>40 :
                salary=((int(msg)-40)*300)+8000
                conn.send(f"Salary is Tk{salary}".encode(FORMAT))

conn.close()
